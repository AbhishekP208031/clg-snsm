// Set year in footer
document.addEventListener('DOMContentLoaded', () => {
  const y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  // Contact form validation (client-side)
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const name = document.getElementById('name');
      const email = document.getElementById('email');
      const message = document.getElementById('message');
      let valid = true;

      [name, email, message].forEach(f => {
        if(!f.value.trim()) { f.classList.add('is-invalid'); valid = false; }
        else f.classList.remove('is-invalid');
      });

      // Basic email check
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if(!emailPattern.test(email.value.trim())){
        email.classList.add('is-invalid'); valid = false;
      }

      if(valid){
        alert('Thanks! This demo form is valid. Connect it to a service to receive emails.');
        form.reset();
      }
    });
  }
});
